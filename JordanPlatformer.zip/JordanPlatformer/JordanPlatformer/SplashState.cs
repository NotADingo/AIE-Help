﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using MonoGame.Extended;
using MonoGame.Extended.Tiled;
using MonoGame.Extended.Tiled.Graphics;
using MonoGame.Extended.ViewportAdapters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JordanPlatformer
{
	class SplashState : AIE.State
	{
		SpriteFont font = null;
		float timer = 3;

		public SplashState(): base()
		{
		}

		public override void Update(ContentManager Content, GameTime gameTime)
		{
		  if(font == null)
			{
				font = Content.Load<SpriteFont>("Arial");
				
			}

			timer -= (float)gameTime.ElapsedGameTime.TotalSeconds;

			if (timer <= 0)
			{
				AIE.StateManager.ChangeState("GAME");
				timer = 3;
			}
		}

		public override void Draw(SpriteBatch sb)
		{
			sb.Begin();
			sb.DrawString(font, "Welcome to Jordan's Platformer", new Vector2(300, 200), Color.White);
			sb.GraphicsDevice.Clear(Color.Black);
			sb.End();
		}

		public override void CleanUp()
		{
			font = null;
			timer = 3;
		}





	}
}
