﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace JordanPlatformer
{
	class GameState : AIE.State
	{

		public static
			bool isLoaded = false;
		SpriteFont font = null;

		public GameState() : base()
		{

		}

		public override void Update(ContentManager Content, GameTime gameTime)
		{
			if(isLoaded == false)
			{
				isLoaded = true;
				font = Content.Load<SpriteFont>("Arial");
			}
		}

		public override void Draw(SpriteBatch sb)
		{
			sb.Begin();
			sb.End();
		}

		public override void CleanUp()
		{
			font = null;
			isLoaded = false;
		}
		



	}
}
