﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace JordanPlatformer
{
	class GameWinState : AIE.State
	{
		public static bool isWinLoaded = false;
		SpriteFont font = null;

		KeyboardState oldState;
		

		public GameWinState() : base()
		{
			

		}

		public override void Update(ContentManager content, GameTime gameTime)
		{
			

			if (isWinLoaded == false)
			{
				isWinLoaded = true;
				GameState.isLoaded = false;
				font = content.Load<SpriteFont>("Arial");
				oldState = Keyboard.GetState();
			}

			KeyboardState newState = Keyboard.GetState();

			if (newState.IsKeyDown(Keys.Enter) == true)
			{

				AIE.StateManager.SetState("SPLASH");

			}

			oldState = newState;
		}

		public override void Draw(SpriteBatch sb)
		{
			sb.Begin();
			sb.DrawString(font, "YOU WIN, THANKS FOR PLAYING! PRESS ESC TO ClOSE!", new Vector2(300, 200), Color.White);
			sb.GraphicsDevice.Clear(Color.Green);
			sb.End();
		}

		public override void CleanUp()
		{
			font = null;
			isWinLoaded = false;
		}
	}

	
}
