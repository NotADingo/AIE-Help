﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace JordanPlatformer
{
	class GameOverState : AIE.State
	{
		public static bool isLoadedOver = false;
		SpriteFont font = null;

		KeyboardState oldState;

		public GameOverState() : base()
		{


		}

		public override void Update(ContentManager Content, GameTime gameTime)
		{
			if (isLoadedOver == false)
			{
				isLoadedOver = true;
				GameState.isLoaded = false;
				font = Content.Load<SpriteFont>("Arial");
				oldState = Keyboard.GetState();
			}

			KeyboardState newState = Keyboard.GetState();

			if (newState.IsKeyDown(Keys.Enter) == true)
			{

				AIE.StateManager.SetState("SPLASH");
				
			}

			oldState = newState;
		}

		public override void Draw(SpriteBatch sb)
		{
			sb.Begin();
			sb.DrawString(font, "Game Over... Press Ecs to close", new Vector2(300, 200), Color.White);
			sb.GraphicsDevice.Clear(Color.Red);
			sb.End();
		}

		public override void CleanUp()
		{
			font = null;
			isLoadedOver = false;
		}


	}
}
