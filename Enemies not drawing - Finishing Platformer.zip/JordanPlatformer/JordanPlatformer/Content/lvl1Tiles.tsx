<?xml version="1.0" encoding="UTF-8"?>
<tileset name="lvl1Tiles" tilewidth="64" tileheight="64" tilecount="72" columns="8">
 <image source="lvl1Tiles.png" width="512" height="576"/>
</tileset>
