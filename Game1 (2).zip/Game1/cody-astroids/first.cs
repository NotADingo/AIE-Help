﻿namespace Game1
{
    internal class first
    {
    }
}