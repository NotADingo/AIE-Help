﻿namespace Game1
{
    internal class hit
    {
    }
}