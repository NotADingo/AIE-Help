﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace PlatformerMonogame1
{
    class Collision
    {
        public Game1 game;

        public Sprite CollideWithPlatforms(Sprite hero, float deltaTime)
        {
            Sprite playerPrediction = new Sprite();
            playerPrediction.position = hero.position;
            playerPrediction.width = hero.width;
            playerPrediction.height = hero.height;
            playerPrediction.offset = hero.offset;
            playerPrediction.UpdateHitBox();

            playerPrediction.position += hero.velocity * deltaTime;

            int playerColumn = (int)playerPrediction.position.X / game.tileHeight;
            int playerRow = (int)playerPrediction.position.Y / game.tileHeight;
            Vector2 playerTile = new Vector2(playerColumn, playerRow);

            Vector2 leftTile = new Vector2(playerTile.X - 1, playerTile.Y);
            Vector2 rightTile = new Vector2(playerTile.X + 1, playerTile.Y);
            Vector2 topTile = new Vector2(playerTile.X, playerTile.Y - 1);
            Vector2 bottomTile = new Vector2(playerTile.X, playerTile.Y + 1);

            Vector2 bottomLeftTile = new Vector2(playerTile.X - 1, playerTile.Y + 1);
            Vector2 bottomRightTile = new Vector2(playerTile.X + 1, playerTile.Y + 1);
            Vector2 topLeftTile = new Vector2(playerTile.X - 1, playerTile.Y - 1);
            Vector2 topRigthTile = new Vector2(playerTile.X + 1, playerTile.Y - 1);

            bool leftCheck = CheckForTile(leftTile);
            bool rightCheck = CheckForTile(rightTile);
            bool topCheck = CheckForTile(topTile);
            bool bottomCheck = CheckForTile(bottomTile);

            bool bottomLeftCheck = CheckForTile(bottomLeftTile);
            bool bottomRightCheck = CheckForTile(bottomRightTile);
            bool topLeftCheck = CheckForTile(topLeftTile);
            bool topRightCheck = CheckForTile(topRigthTile);

            // Check for collisions with tiles left of the player
            if (leftCheck == true)
            {
                hero = CollideLeft(hero, leftTile, playerPrediction);
            }
            // Check for collisions with tiles right of the player
            if (rightCheck == true)
            {
                hero = CollideRight(hero, rightTile, playerPrediction);
            }
            // Check for collisions with tiles below the player
            if (bottomCheck == true)
            {
                hero = CollideBelow(hero, bottomTile, playerPrediction);
            }
            // Check for collisions with tiles above the player
            if (topCheck == true)
            {
                hero = CollideAbove(hero, topTile, playerPrediction);
            }
            // Check for collisions with tiles below and to the left of the player
            if (leftCheck == false && bottomCheck == false && bottomLeftCheck == true)
            {
                // Properly check for diagonals
                hero = CollideBottomDiagonals(hero, bottomLeftTile, playerPrediction);
            }
            // Check for collisions with tiles above and to the left of the player
            if (leftCheck == false && topCheck == false && topLeftCheck == true)
            {
                // Properly check for diagonals
                hero = CollideAboveDiagonals(hero, topLeftTile, playerPrediction);
            }
            // Check for collisions with tiles above and to the left of the player
            if (rightCheck == false && topCheck == false && topRightCheck == true)
            {
                // Properly check for diagonals
                hero = CollideAboveDiagonals(hero, topRigthTile, playerPrediction);
            }
            // Check for collisions with tiles below and to the right of the player
            if (rightCheck == false && bottomCheck == false && bottomRightCheck ==
           true)
            {
                // Properly check for diagonals
                hero = CollideBottomDiagonals(hero, bottomRightTile,
               playerPrediction);
            }
            return hero;
        }
        Sprite CollideBottomDiagonals(Sprite hero, Vector2 tileIndex, Sprite playerPrediction)
        {
            Sprite tile = game.levelGrid[(int)tileIndex.X, (int)tileIndex.Y];
            int leftEdgeDistance = Math.Abs(tile.leftEdge -
           playerPrediction.rightEdge);
            int rightEdgeDistance = Math.Abs(tile.rightEdge -
            playerPrediction.leftEdge);
            int topEdgeDistance = Math.Abs(tile.topEdge -
           playerPrediction.bottomEdge);
            if (IsColliding(playerPrediction, tile) == true)
            {
                if (topEdgeDistance < rightEdgeDistance && topEdgeDistance <
               leftEdgeDistance)
                {
                    // If top edge closest, collision is happening above the platform
                    hero.position.Y = tile.topEdge - hero.offset.Y;
                    hero.velocity.Y = 0;
                }
                else if (rightEdgeDistance < leftEdgeDistance)
                {
                    // if right edge closest, collision is happening to the right ofthe platform
                    hero.position.X = tile.rightEdge + hero.offset.X;
                    hero.velocity.X = 0;
                }
                else
                {
                    // else if left edge closest, collision happening left of thplatform
                    hero.position.X = tile.leftEdge - hero.offset.X;
                    hero.velocity.X = 0;
                }
            }
            return hero;
        }
        Sprite CollideAboveDiagonals(Sprite hero, Vector2 tileIndex, Sprite playerPrediction)
        {
            Sprite tile = game.levelGrid[(int)tileIndex.X, (int)tileIndex.Y];
            int leftEdgeDistance = Math.Abs(tile.rightEdge -
           playerPrediction.leftEdge);
            int rightEdgeDistance = Math.Abs(tile.leftEdge -
           playerPrediction.rightEdge);
            int bottomEdgeDistance = Math.Abs(tile.bottomEdge -
           playerPrediction.topEdge);
            if (IsColliding(playerPrediction, tile) == true)
            {
                if (bottomEdgeDistance < leftEdgeDistance && bottomEdgeDistance <
               rightEdgeDistance)
                {
                    // If top edge closest and overlapping on top edge
                    hero.position.Y = tile.bottomEdge + hero.offset.Y;
                    hero.velocity.Y = 0;
                }
                else if (leftEdgeDistance < rightEdgeDistance)
                {
                    // else if left edge closest and overlapping on left edge
                    hero.position.X = tile.rightEdge + hero.offset.X;
                    hero.velocity.X = 0;
                }
                else
                {
                    // else if right edge closest and overlapping on right edge
                    hero.position.X = tile.leftEdge - hero.offset.X;
                    hero.velocity.X = 0;
                }
            }
            return hero;
        }
        private bool CheckForTile(Vector2 leftTile)
        {
            throw new NotImplementedException();
        }

        Sprite CollideAbove(Sprite hero, Vector2 tileIndex, Sprite playerPrediction)
        {
            Sprite tile = game.levelGrid[(int)tileIndex.X, (int)tileIndex.Y];
            if (IsColliding(playerPrediction, tile) == true)
            {
                hero.position.Y = tile.bottomEdge + hero.offset.Y;

 
                hero.velocity.Y = 0;
            }
            return hero;
        }
        Sprite CollideRight(Sprite hero, Vector2 tileIndex, Sprite playerPrediction)
        {
            Sprite tile = game.levelGrid[(int)tileIndex.X, (int)tileIndex.Y];

            if (IsColliding(playerPrediction, tile) == true)
            {
                hero.position.X = tile.leftEdge - hero.offset.X;
                hero.velocity.X = 0;
            }

            return hero;
        }
        Sprite CollideBelow(Sprite hero, Vector2 tileIndex, Sprite playerPrediction)
        {
            Sprite tile = game.levelGrid[(int)tileIndex.X, (int)tileIndex.Y];
            if (IsColliding(playerPrediction, tile) == true)
            {
                hero.position.Y = tile.topEdge - hero.offset.Y;
                hero.velocity.Y = 0;
            }
            return hero;
        }
        Sprite CollideLeft(Sprite hero, Vector2 tileIndex, Sprite playerPrediction)
        {
            Sprite tile = game.levelGrid[(int)tileIndex.X, (int)tileIndex.Y];
            if (IsColliding(playerPrediction, tile) == true)
            {
                hero.position.X = tile.rightEdge + hero.offset.X;
                hero.velocity.X = 0;
            }
            return hero;
        }
        public bool IsColliding(Sprite hero, Sprite otherSprite)
        {
            if (hero.rightEdge < otherSprite.leftEdge ||
            hero.leftEdge > otherSprite.rightEdge ||
            hero.bottomEdge < otherSprite.topEdge ||
            hero.topEdge > otherSprite.bottomEdge)
            {
                return false;
            }


            // else, the two AABB rectangles overlap, therefore there is a collision
            return true;
        }
        
    }
}
