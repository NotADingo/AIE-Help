﻿namespace PlatformerMonogame1
{
    internal class platform
    {
    }
}