<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="Tileset" tilewidth="64" tileheight="64" tilecount="72" columns="8">
 <image source="Tileset.png" width="512" height="576"/>
</tileset>
